import { useEffect, useState } from "react";
import axios from "../utils/api";
import { 
    Trophy, 
    Video, 
    Search, 
    Bell, 
    ChevronRight, 
    Twitch, 
    Youtube, 
    Twitter 
} from 'lucide-react';

const Home = () => {
    const [events, setEvents] = useState([]);
    const [videos, setVideos] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchData = async () => {
            try {
                const eventsRes = await axios.get("/events/latest");
                const videosRes = await axios.get("/videos/latest");

                setEvents(eventsRes.data || []);
                setVideos(videosRes.data || []);
            } catch (error) {
                console.error("Error fetching data:", error);
            } finally {
                setLoading(false);
            }
        };

        fetchData();
    }, []);

    return (
        <div className="bg-gradient-to-br from-[#121212] to-[#1e1e2e] text-white min-h-screen p-4 md:p-6 flex flex-col md:flex-row">
            {/* Sidebar */}
            <aside className="w-full md:w-1/5 bg-[#1a1a2e] p-4 rounded-2xl shadow-2xl mb-4 md:mb-0 md:mr-6">
                <h2 className="text-2xl font-bold text-indigo-400 border-b-2 border-indigo-500 pb-3 mb-4">
                    <Trophy className="inline-block mr-2 -mt-1" size={24} />
                    Categories
                </h2>
                <div className="grid grid-cols-2 md:grid-cols-1 gap-3">
                    {["Shooter", "RPG", "MOBA", "Battle Royale", "Sports", "Strategy"].map((category, index) => (
                        <div 
                            key={index} 
                            className="bg-[#16213e] p-3 rounded-xl text-center hover:bg-indigo-900 
                            transition-all duration-300 transform hover:scale-105 cursor-pointer 
                            hover:shadow-lg flex items-center justify-between"
                        >
                            <span>{category}</span>
                            <ChevronRight size={20} className="text-indigo-400" />
                        </div>
                    ))}
                </div>
            </aside>

            {/* Main Content */}
            <div className="w-full md:w-4/5">
                {/* Navigation Bar */}
                <nav className="flex flex-col md:flex-row justify-between items-center mb-6 p-4 bg-[#1a1a2e] rounded-2xl shadow-2xl">
                    <h1 className="text-3xl font-bold text-indigo-400 mb-4 md:mb-0">Esports Hub</h1>
                    <div className="flex w-full md:w-auto items-center space-x-4">
                        <div className="relative flex-grow">
                            <input 
                                type="text" 
                                placeholder="Search events, videos..." 
                                className="w-full p-3 pl-10 rounded-xl bg-[#16213e] text-white 
                                focus:ring-2 focus:ring-indigo-500 transition-all duration-300"
                            />
                            <Search 
                                className="absolute left-3 top-1/2 transform -translate-y-1/2 
                                text-gray-400" 
                                size={20} 
                            />
                        </div>
                        <div className="flex items-center space-x-3">
                            <button className="p-3 bg-indigo-600 rounded-xl hover:bg-indigo-700 
                            transition-colors duration-300 font-semibold">
                                Sign In
                            </button>
                            <div className="p-3 bg-[#16213e] rounded-xl relative hover:bg-gray-700 
                            transition-colors duration-300 cursor-pointer">
                                <Bell size={20} />
                                <span className="absolute -top-2 -right-2 bg-red-500 text-white 
                                rounded-full px-2 py-1 text-xs">3</span>
                            </div>
                        </div>
                    </div>
                </nav>

                {/* Featured Banner */}
                <div className="bg-gradient-to-r from-indigo-600 to-purple-600 p-6 text-center 
                rounded-2xl shadow-2xl mb-6 hover:scale-[1.02] transition-transform duration-300">
                    <h2 className="text-2xl font-bold mb-3">Global Esports Championship</h2>
                    <p className="text-gray-100 mb-4">Live Now: Top Teams Battling for Glory</p>
                    <button className="bg-white text-indigo-800 px-6 py-3 rounded-xl 
                    font-semibold hover:bg-gray-100 transition-colors duration-300">
                        Watch Live
                    </button>
                </div>

                {loading ? (
                    <div className="flex justify-center items-center h-64">
                        <div className="animate-spin rounded-full h-16 w-16 border-t-4 border-indigo-500"></div>
                    </div>
                ) : (
                    <>
                        {/* Latest Events Section */}
                        <section className="mb-8 bg-[#1a1a2e] p-6 rounded-2xl shadow-2xl">
                            <div className="flex justify-between items-center mb-4">
                                <h2 className="text-2xl font-bold text-indigo-400 flex items-center">
                                    <Trophy className="mr-2" size={24} /> Latest Events
                                </h2>
                                <a href="#" className="text-gray-400 hover:text-indigo-400 transition-colors">
                                    View All
                                </a>
                            </div>
                            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                                {events.length > 0 ? (
                                    events.map((event) => (
                                        <div 
                                            key={event._id} 
                                            className="bg-[#16213e] p-5 rounded-2xl 
                                            hover:scale-105 transition-transform duration-300 
                                            shadow-lg hover:shadow-2xl cursor-pointer"
                                        >
                                            <h3 className="text-lg font-semibold text-indigo-300 mb-2">
                                                {event.title}
                                            </h3>
                                            <p className="text-gray-400 text-sm mb-3">
                                                {event.description || 'Upcoming Tournament'}
                                            </p>
                                            <div className="flex justify-between items-center">
                                                <span className="text-green-400 text-sm">
                                                    Registration Open
                                                </span>
                                                <ChevronRight className="text-indigo-400" size={20} />
                                            </div>
                                        </div>
                                    ))
                                ) : (
                                    <p className="col-span-full text-center text-gray-400">
                                        No events available. Stay tuned!
                                    </p>
                                )}
                            </div>
                        </section>

                        {/* Latest Videos Section */}
                        <section className="mb-8 bg-[#1a1a2e] p-6 rounded-2xl shadow-2xl">
                            <div className="flex justify-between items-center mb-4">
                                <h2 className="text-2xl font-bold text-blue-400 flex items-center">
                                    <Video className="mr-2" size={24} /> Latest Videos
                                </h2>
                                <a href="#" className="text-gray-400 hover:text-blue-400 transition-colors">
                                    View All
                                </a>
                            </div>
                            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                                {videos.length > 0 ? (
                                    videos.map((video) => (
                                        <div 
                                            key={video._id} 
                                            className="bg-[#16213e] p-5 rounded-2xl 
                                            hover:scale-105 transition-transform duration-300 
                                            shadow-lg hover:shadow-2xl cursor-pointer"
                                        >
                                            <h3 className="text-lg font-semibold text-blue-300 mb-2">
                                                {video.title}
                                            </h3>
                                            <p className="text-gray-400 text-sm mb-3">
                                                {video.description || 'Gameplay Highlights'}
                                            </p>
                                            <div className="flex justify-between items-center">
                                                <span className="text-red-400 text-sm">
                                                    Trending
                                                </span>
                                                <ChevronRight className="text-blue-400" size={20} />
                                            </div>
                                        </div>
                                    ))
                                ) : (
                                    <p className="col-span-full text-center text-gray-400">
                                        No videos available. Check back soon!
                                    </p>
                                )}
                            </div>
                        </section>

                        {/* Footer */}
                        <footer className="bg-[#1a1a2e] p-6 rounded-2xl text-center">
                            <p className="text-gray-400 mb-4">
                                &copy; 2025 Esports Hub. All Rights Reserved.
                            </p>
                            <div className="flex justify-center space-x-6 mb-4">
                                <a href="#" className="text-gray-400 hover:text-indigo-400 transition-colors">
                                    <Twitch size={24} />
                                </a>
                                <a href="#" className="text-gray-400 hover:text-red-500 transition-colors">
                                    <Youtube size={24} />
                                </a>
                                <a href="#" className="text-gray-400 hover:text-blue-400 transition-colors">
                                    <Twitter size={24} />
                                </a>
                            </div>
                            <div className="flex justify-center space-x-4">
                                {["About Us", "Contact", "Privacy Policy", "Terms & Conditions"].map((link) => (
                                    <a 
                                        key={link} 
                                        href="#" 
                                        className="text-gray-400 hover:text-indigo-400 transition-colors text-sm"
                                    >
                                        {link}
                                    </a>
                                ))}
                            </div>
                        </footer>
                    </>
                )}
            </div>
        </div>
    );
};

export default Home;
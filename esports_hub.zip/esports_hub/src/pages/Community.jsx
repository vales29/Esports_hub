import React, { useState, useEffect, useRef } from "react";
import { useAuth } from "../context/AuthContext";
import io from "socket.io-client";

const Community = () => {
    const { user } = useAuth();
    const [messages, setMessages] = useState([]);
    const [newMessage, setNewMessage] = useState("");
    const messagesEndRef = useRef(null);

    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }, [messages]);

    const sendMessage = (e) => {
        e.preventDefault();
        if (!newMessage.trim()) return;

        const msgData = {
            username: user?.username || "Guest",
            text: newMessage.trim(),
            timestamp: new Date().toISOString(),
        };

        setMessages((prev) => [...prev, msgData]);
        setNewMessage("");
    };

    return (
        <div className="min-h-screen flex flex-col items-center bg-gray-900 text-white p-6">
            <div className="w-full max-w-2xl bg-gray-800 p-4 rounded-lg shadow-lg">
                <h1 className="text-2xl font-bold mb-4 text-center">💬 Community Chat</h1>

                <div className="h-96 overflow-y-auto bg-gray-700 p-4 rounded-lg mb-4 space-y-3">
                    {messages.length === 0 ? (
                        <p className="text-gray-400 text-center">No messages yet. Start the conversation!</p>
                    ) : (
                        messages.map((msg, index) => (
                            <div
                                key={index}
                                className={`p-3 rounded-lg max-w-[80%] ${
                                    msg.username === user?.username ? "bg-blue-600 ml-auto" : "bg-gray-600"
                                }`}
                            >
                                <div className="text-sm text-gray-300">{msg.username}</div>
                                <p className="text-white">{msg.text}</p>
                            </div>
                        ))
                    )}
                    <div ref={messagesEndRef} />
                </div>

                {user ? (
                    <form onSubmit={sendMessage} className="flex items-center gap-2">
                        <input
                            type="text"
                            value={newMessage}
                            onChange={(e) => setNewMessage(e.target.value)}
                            placeholder="Type your message..."
                            className="flex-1 px-3 py-2 bg-gray-700 rounded text-white outline-none focus:ring-2 focus:ring-blue-500"
                            maxLength={500}
                        />
                        <button
                            type="submit"
                            disabled={!newMessage.trim()}
                            className="px-4 py-2 bg-blue-600 rounded hover:bg-blue-700 disabled:opacity-50"
                        >
                            Send
                        </button>
                    </form>
                ) : (
                    <p className="text-gray-400 text-center">Log in to join the chat.</p>
                )}
            </div>
        </div>
    );
};

export default Community;
